// Creates the tables on whatever database the .env / host variables point to.
// Needed on hosting platforms where the mysql command line is not available.
// WARNING: it drops and recreates every table, so run it only for the first setup.
const fs = require('fs');
const path = require('path');
const mysql = require('mysql2/promise');
require('dotenv').config();
const e = process.env;

async function setup() {
  const conn = await mysql.createConnection({
    host: e.DB_HOST || e.MYSQLHOST || 'localhost',
    port: Number(e.DB_PORT || e.MYSQLPORT || 3306),
    user: e.DB_USER || e.MYSQLUSER || 'root',
    password: e.DB_PASSWORD ?? e.MYSQLPASSWORD ?? '',
    database: e.DB_NAME || e.MYSQLDATABASE || 'raitu_raksha',
    ssl: e.DB_SSL === 'true' ? { rejectUnauthorized: false } : undefined,
    multipleStatements: true
  });
  // hosted users usually cannot create a database, so skip those two lines of the schema file
  const sql = fs.readFileSync(path.join(__dirname, 'schema.sql'), 'utf8')
    .split('\n').filter(l => !/^\s*(CREATE DATABASE|USE)\b/i.test(l)).join('\n');
  await conn.query(sql);
  await conn.end();
  console.log('tables created');
}

module.exports = setup;
if (require.main === module) setup().catch(err => { console.error('setup failed:', err.message); process.exit(1); });
