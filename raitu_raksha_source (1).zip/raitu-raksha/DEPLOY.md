# Deploying Raitu Raksha

The app is one Node.js service plus one MySQL database. On the first start with an empty
database it creates the tables and loads the starter knowledge base by itself, so there is
no manual database step. Restarting never wipes data.

## Option A: Railway (web service and MySQL in one place)

1. Put the project on GitHub (the `.gitignore` already keeps `node_modules` and `.env` out):
   `git init && git add . && git commit -m "Raitu Raksha" ` then push to a new repository.
2. On railway.app: New Project > Deploy from GitHub repo > pick the repository.
3. In the same project: New > Database > MySQL.
4. Open the web service > Variables and add these (the `${{MySQL...}}` ones are references
   to the MySQL service; rename `MySQL` if your database service has another name):
   - `MYSQLHOST`     = `${{MySQL.MYSQLHOST}}`
   - `MYSQLPORT`     = `${{MySQL.MYSQLPORT}}`
   - `MYSQLUSER`     = `${{MySQL.MYSQLUSER}}`
   - `MYSQLPASSWORD` = `${{MySQL.MYSQLPASSWORD}}`
   - `MYSQLDATABASE` = `${{MySQL.MYSQLDATABASE}}`
   - `JWT_SECRET`    = any long random string (30+ characters)
5. Web service > Settings > Networking > Generate Domain. Open the link.
6. Check `https://your-domain/health` shows `{"ok":true}`, then log in as the agronomist.

## Option B: Render (web service) + a free MySQL from Aiven or TiDB Cloud

1. Create the MySQL database on Aiven or TiDB Cloud and note host, port, user, password, database name.
2. On render.com: New > Web Service > connect the GitHub repo.
   Build command `npm install`, start command `npm start`.
3. Environment variables: `DB_HOST`, `DB_PORT`, `DB_USER`, `DB_PASSWORD`, `DB_NAME`,
   `DB_SSL=true`, `JWT_SECRET`.

## After deploying

- Log in as `agronomist@raitu-raksha.in` / `agro@123` and **change that password**
  (or edit the seed before the first start). Anyone who reads the README knows the default.
- Free plans can sleep when idle, so open the site once before your demo.
- To reset the knowledge base to the starter data, run `npm run setup` against the database.
  It drops all tables, including farmer accounts and history.
