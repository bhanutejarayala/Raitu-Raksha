require('dotenv').config();
const mysql = require('mysql2/promise');

// Works locally (DB_*) and on Railway (MYSQL* variables are filled in automatically).
const e = process.env;
const pool = mysql.createPool({
  host: e.DB_HOST || e.MYSQLHOST || 'localhost',
  port: Number(e.DB_PORT || e.MYSQLPORT || 3306),
  user: e.DB_USER || e.MYSQLUSER || 'root',
  password: e.DB_PASSWORD ?? e.MYSQLPASSWORD ?? '',
  database: e.DB_NAME || e.MYSQLDATABASE || 'raitu_raksha',
  // cloud databases such as Aiven or TiDB need an encrypted connection: set DB_SSL=true
  ssl: e.DB_SSL === 'true' ? { rejectUnauthorized: false } : undefined,
  waitForConnections: true,
  connectionLimit: 8
});

module.exports = pool;
